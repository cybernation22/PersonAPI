﻿using FluentValidation;
using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using PersonInfoAPI.CustomModels;
using PersonInfoAPI.DbModels;
using PersonInfoAPI.Filters;
using PersonInfoAPI.MiddleWare;
using PersonInfoAPI.Models;
using PersonInfoAPI.RepoSitory;
using System.Linq;
using System.Threading;

namespace PersonInfoAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });


                                           
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2).AddFluentValidation();

            services.AddTransient<IValidator<PersonModel>, PersonValidation>();


            services.AddDbContext<TBCContext>(options => options.UseSqlServer(Configuration.GetConnectionString("TBCDB")));
            services.AddScoped<UnitOfWork>();

            services.AddScoped<ActionFilter>();




        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }




            app.Use((context, next) =>
            {
                var curLang = context.Request.Headers["Accept-Language"].ToString();
                var zeroItem = curLang.Split(',').FirstOrDefault();
                var language = "en"; 

                switch (zeroItem)
                {
                    case "ge":
                        language = "ge";
                        break;
                    case "ru":
                        language = "ru";
                        break;
                }

                
                Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo(language);
                Thread.CurrentThread.CurrentUICulture = Thread.CurrentThread.CurrentCulture;
                
                context.Items["curLang"] = language;
                context.Items["curCulture"] = Thread.CurrentThread.CurrentUICulture.Name;

                return next();
            });

          

            app.UseMiddleware<ExceptionLogger>();

          


            app.UseCors(builder =>
                builder.AllowAnyOrigin()
                .AllowAnyMethod()
                .AllowAnyHeader()
                .AllowAnyOrigin());


            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Person}/{action=Index}/{id?}");
            });
        }
    }
}
