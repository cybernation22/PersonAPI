﻿using Microsoft.AspNetCore.Mvc;
using PersonInfoAPI.CustomModels;
using PersonInfoAPI.DbModels;
using PersonInfoAPI.Filters;
using PersonInfoAPI.RepoSitory;
using System.Collections.Generic;
using System.Linq;

namespace PersonInfoAPI.Controllers
{
    public class PersonController : Controller
    {


        public UnitOfWork _uow;

        public PersonController(UnitOfWork uow)
        {
            _uow = uow;
        }


        [HttpPost]
        [ServiceFilter(typeof(ActionFilter))]

        public IActionResult AddPerson([FromBody]PersonModel person)
        {


            var p = _uow.GenericRepo.Add<Person>(new Person()
            {
                Fname = person.Fname,
                Lname = person.Lname,
                CityId = person.CityId,
                Sex = person.Sex,
                PrivateNumber = person.PrivateNumber,
                BirthDate = person.BirthDate,
                Status = true
            });



            foreach (var mob in person.PhoneModel)
            {
                _uow.GenericRepo.Add<Phones>(new Phones()
                {
                    PhoneNumber = mob.PhoneNumber,
                    Status = true,
                    TypeId = mob.TypeId,
                    Person = p
                });

            }



            _uow.Save();

            return Ok();
        }



        [HttpPost]
        [ServiceFilter(typeof(ActionFilter))]
        public IActionResult ModifyPerson([FromBody]PersonModel person)
        {

            var curPerson = _uow.GenericRepo.GetByID<Person>(person.Id);
            var personMobiles = _uow.GenericRepo.GetAll<Phones>().Where(x => x.PersonId == curPerson.Id && x.Status == true).ToList();

            if (person.PhoneModel != null)
            {
                foreach (var item in personMobiles)
                {
                    var PhoneToModify = person.PhoneModel.Where(x => x.Id == item.Id).FirstOrDefault();
                    if (PhoneToModify != null)
                    {
                        PhoneToModify.PhoneNumber = item.PhoneNumber;
                        PhoneToModify.TypeId = item.TypeId;
                    }
                    else
                    {
                        _uow.GenericRepo.Delete<Phones>(item);
                    }
                }

                foreach (var item in person.PhoneModel)
                {

                    var phonesToInsert = person.PhoneModel.Except(personMobiles).ToList<Phones>();
                    _uow.GenericRepo.AddRange<Phones>(phonesToInsert);

                }
            }
            else
            {
                _uow.GenericRepo.DeleteRange<Phones>(personMobiles);
            }

            curPerson.Fname = person.Fname;
            curPerson.Lname = person.Lname;
            curPerson.PrivateNumber = person.PrivateNumber;
            curPerson.BirthDate = person.BirthDate;
            curPerson.CityId = person.CityId;
            _uow.Save();



            return Ok();
        }


        [HttpPost]
        public IActionResult AddRelatedPerson([FromBody]ICollection<RelatedPeopleModel> relatedPersons)
        {
            var curPersonID = relatedPersons.FirstOrDefault().Personid;

            var curPerson = _uow.GenericRepo.GetByID<Person>(curPersonID);




            foreach (var item in relatedPersons)
            {
                var p = _uow.GenericRepo.Add<Person>(new Person()
                {
                    Fname = item.RelatedPerson.Fname,
                    Lname = item.RelatedPerson.Lname,
                    CityId = item.RelatedPerson.CityId,
                    Sex = item.RelatedPerson.Sex,
                    PrivateNumber = item.RelatedPerson.PrivateNumber,
                    BirthDate = item.RelatedPerson.BirthDate,
                    Status = true
                });

                var rel = _uow.GenericRepo.Add(new RelatedPeople()
                {
                    RelatedPerson = p,
                    RelationTypeId = item.RelationTypeId,
                    Status = true
                });

            }

            _uow.Save();


            return Ok();
        }


        [HttpPost]
        public IActionResult DeleteRelatedPeople([FromBody]ICollection<RelatedPeople> relatedPersons)
        {
            _uow.GenericRepo.DeleteRange<RelatedPeople>(relatedPersons.ToList());

            _uow.Save();


            return Ok();
        }

        [HttpPost]
        public IActionResult DeletePerson([FromBody]long personID)
        {

            var curPerson = _uow.GenericRepo.GetByID<Person>(personID);
            _uow.GenericRepo.Delete<Person>(curPerson);

            _uow.Save();


            return Ok();
        }

        [HttpGet]
        public IActionResult GetPersonFullInfo([FromQuery]long personID)
        {
            Person Person;

            var curPerson = _uow.GenericRepo.GetByID<Person>(personID);

            var image = _uow.GenericRepo.GetByID<PersonImages>((long)curPerson.ImgId);

            var phones = _uow.GenericRepo.GetAll<Phones>().Where(x => x.PersonId == curPerson.Id).ToList();



            var relatedPeople = _uow.GenericRepo.GetAll<RelatedPeople>().Where(x => x.RelatedPersonId == curPerson.Id).ToList();


            Person = curPerson;
            Person.RelatedPeople = relatedPeople;
            Person.Phones = phones;
            Person.Img = image;

            return Ok(Person);
        }

        [HttpGet]
        public IActionResult SearchPerson([FromQuery]string first, string last, string pn, int pageSize = 1)
        {
            var personLst = _uow.GenericRepo.GetAll<Person>().Where(x => x.Fname.Contains(first) || x.Lname.Contains(last) ||

            x.PrivateNumber.Contains(pn)).GetPaged<Person>(pageSize, 50);



            return Ok(personLst.Results);

        }


        [HttpPost]
        public IActionResult AddModifyImage([FromBody]PersonImageP pImage)
        {

            var curPerson = _uow.GenericRepo.GetByID<PersonModel>(pImage.PersonID);


            var img = _uow.GenericRepo.GetByID<PersonImages>((int)curPerson.ImgId);

            if (img != null)
            {
                img.Image = pImage.ImageLoc;
                img.Status = true;
            }
            else
            {
                var personImage = _uow.GenericRepo.Add(new PersonImages
                {
                    Image = pImage.ImageLoc,
                Status = true
                });

                curPerson.Img = personImage;
            }

            _uow.Save();



            return Ok();
        }


        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
    }
}