﻿using Microsoft.AspNetCore.Http;
using System;
using System.Threading.Tasks;

namespace PersonInfoAPI.MiddleWare
{
    public class ExceptionLogger
    {
        private readonly RequestDelegate _next;

        public ExceptionLogger(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine($"Exception : {e.Message}");
                throw;
            }
        }
    }
}
