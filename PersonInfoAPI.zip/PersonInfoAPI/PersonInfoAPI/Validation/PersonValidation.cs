﻿using FluentValidation;
using PersonInfoAPI.CustomModels;
using System.Linq;

namespace PersonInfoAPI.Models
{
    public class PersonValidation : AbstractValidator<PersonModel>
    {
        public PersonValidation()
        {
            RuleFor(x => x.Fname).NotNull().MinimumLength(2).MaximumLength(50);
            RuleFor(x => x.Lname).NotNull().MinimumLength(2).MaximumLength(50);
            RuleFor(x => x.PrivateNumber).NotNull().MinimumLength(11).MaximumLength(11);
            RuleFor(x => x.BirthDate).NotNull();
            RuleFor(x => x.Age).GreaterThanOrEqualTo(18);
            RuleFor(x => x.SexEnum).IsInEnum().WithMessage("'sex' should be 'male' - 'female' range");
            RuleFor(x => x.IsCorrectFirstName). Must(x=>x == true).WithMessage("First name should be one language characters");
            RuleFor(x => x.IsCorrectLastName).Must(x => x == true).WithMessage("Last name should be one language characters");
            RuleForEach(x => x.PhoneModel).Where(x => x != null).ChildRules(ph =>
                {
                    ph.RuleFor(x => x.PhoneNumber).MinimumLength(4).MaximumLength(50);
                    ph.RuleFor(x => x.phoneTypesEnum).IsInEnum().WithMessage(x => x.GetPhoneTypeEnums);
                });


            RuleForEach(x => x.RelatedPeopleModel).Where(x => x != null).ChildRules(ph =>
            {
                ph.RuleFor(x => x.RelatedPeopleTypesEnum).IsInEnum().WithMessage(x => x.GetRelatedPeopleTypesEnums);
            });



        }
    }
}


