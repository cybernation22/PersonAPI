﻿using System;
using System.Collections.Generic;

namespace PersonInfoAPI.DbModels
{
    public partial class Cities
    {
        public Cities()
        {
            Person = new HashSet<Person>();
        }

        public long Id { get; set; }
        public string Name { get; set; }
        public bool Status { get; set; }

        public virtual ICollection<Person> Person { get; set; }
    }
}
