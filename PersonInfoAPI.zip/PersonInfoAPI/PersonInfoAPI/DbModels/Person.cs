﻿using System;
using System.Collections.Generic;

namespace PersonInfoAPI.DbModels
{
    public partial class Person
    {
        public Person()
        {
            Phones = new HashSet<Phones>();
            RelatedPeople = new HashSet<RelatedPeople>();
        }

        public long Id { get; set; }
        public string Fname { get; set; }
        public string Lname { get; set; }
        public string PrivateNumber { get; set; }
        public DateTime BirthDate { get; set; }
        public long? CityId { get; set; }
        public long? ImgId { get; set; }
        public bool Status { get; set; }
        public int? Sex { get; set; }

        public virtual Cities City { get; set; }
        public virtual PersonImages Img { get; set; }
        public virtual Gender SexNavigation { get; set; }
        public virtual ICollection<Phones> Phones { get; set; }
        public virtual ICollection<RelatedPeople> RelatedPeople { get; set; }
    }
}
