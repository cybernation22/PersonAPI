﻿using System;
using System.Collections.Generic;

namespace PersonInfoAPI.DbModels
{
    public partial class PhoneTypes
    {
        public PhoneTypes()
        {
            Phones = new HashSet<Phones>();
        }

        public long Id { get; set; }
        public string Name { get; set; }
        public bool Status { get; set; }

        public virtual ICollection<Phones> Phones { get; set; }
    }
}
