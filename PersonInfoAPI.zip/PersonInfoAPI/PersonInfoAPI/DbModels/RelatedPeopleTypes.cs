﻿using System;
using System.Collections.Generic;

namespace PersonInfoAPI.DbModels
{
    public partial class RelatedPeopleTypes
    {
        public RelatedPeopleTypes()
        {
            RelatedPeople = new HashSet<RelatedPeople>();
        }

        public long Id { get; set; }
        public string Name { get; set; }
        public bool Status { get; set; }

        public virtual ICollection<RelatedPeople> RelatedPeople { get; set; }
    }
}
