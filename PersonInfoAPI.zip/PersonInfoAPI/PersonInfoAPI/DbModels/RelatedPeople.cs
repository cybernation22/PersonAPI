﻿namespace PersonInfoAPI.DbModels
{
    public partial class RelatedPeople
    {
        public long Id { get; set; }
        public long? RelationTypeId { get; set; }
        public long? RelatedPersonId { get; set; }
        public bool Status { get; set; }

        public virtual Person RelatedPerson { get; set; }
        public virtual RelatedPeopleTypes RelationType { get; set; }
    }
}
