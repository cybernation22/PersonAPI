﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace PersonInfoAPI.DbModels
{
    public partial class TBCContext : DbContext
    {
        public TBCContext()
        {
        }

        public TBCContext(DbContextOptions<TBCContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Cities> Cities { get; set; }
        public virtual DbSet<Gender> Gender { get; set; }
        public virtual DbSet<Person> Person { get; set; }
        public virtual DbSet<PersonImages> PersonImages { get; set; }
        public virtual DbSet<PhoneTypes> PhoneTypes { get; set; }
        public virtual DbSet<Phones> Phones { get; set; }
        public virtual DbSet<RelatedPeople> RelatedPeople { get; set; }
        public virtual DbSet<RelatedPeopleTypes> RelatedPeopleTypes { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=.\\xz;Database=TBC;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<Cities>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Name).HasMaxLength(50);

                entity.Property(e => e.Status).HasColumnName("status");
            });

            modelBuilder.Entity<Gender>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Name).HasMaxLength(10);
            });

            modelBuilder.Entity<Person>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.BirthDate).HasColumnType("datetime");

                entity.Property(e => e.CityId).HasColumnName("CityID");

                entity.Property(e => e.Fname)
                    .IsRequired()
                    .HasColumnName("FName")
                    .HasMaxLength(100);

                entity.Property(e => e.ImgId).HasColumnName("ImgID");

                entity.Property(e => e.Lname)
                    .IsRequired()
                    .HasColumnName("LName")
                    .HasMaxLength(100);

                entity.Property(e => e.PrivateNumber)
                    .IsRequired()
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.Status).HasColumnName("status");

                entity.HasOne(d => d.City)
                    .WithMany(p => p.Person)
                    .HasForeignKey(d => d.CityId)
                    .HasConstraintName("FK__Person__CityID__182C9B23");

                entity.HasOne(d => d.Img)
                    .WithMany(p => p.Person)
                    .HasForeignKey(d => d.ImgId)
                    .HasConstraintName("FK__Person__ImgID__1920BF5C");

                entity.HasOne(d => d.SexNavigation)
                    .WithMany(p => p.Person)
                    .HasForeignKey(d => d.Sex)
                    .HasConstraintName("FK__Person__Sex__38996AB5");
            });

            modelBuilder.Entity<PersonImages>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Image)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.Status).HasColumnName("status");
            });

            modelBuilder.Entity<PhoneTypes>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Name).HasMaxLength(50);

                entity.Property(e => e.Status).HasColumnName("status");
            });

            modelBuilder.Entity<Phones>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.PersonId).HasColumnName("PersonID");

                entity.Property(e => e.PhoneNumber).HasMaxLength(50);

                entity.Property(e => e.Status).HasColumnName("status");

                entity.Property(e => e.TypeId).HasColumnName("TypeID");

                entity.HasOne(d => d.Person)
                    .WithMany(p => p.Phones)
                    .HasForeignKey(d => d.PersonId)
                    .HasConstraintName("FK__Phones__PersonID__1CF15040");

                entity.HasOne(d => d.Type)
                    .WithMany(p => p.Phones)
                    .HasForeignKey(d => d.TypeId)
                    .HasConstraintName("FK__Phones__TypeID__1BFD2C07");
            });

            modelBuilder.Entity<RelatedPeople>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.RelatedPersonId).HasColumnName("RelatedPersonID");

                entity.Property(e => e.RelationTypeId).HasColumnName("RelationTypeID");

                entity.Property(e => e.Status).HasColumnName("status");

                entity.HasOne(d => d.RelatedPerson)
                    .WithMany(p => p.RelatedPeople)
                    .HasForeignKey(d => d.RelatedPersonId)
                    .HasConstraintName("FK__RelatedPe__Relat__20C1E124");

                entity.HasOne(d => d.RelationType)
                    .WithMany(p => p.RelatedPeople)
                    .HasForeignKey(d => d.RelationTypeId)
                    .HasConstraintName("FK__RelatedPe__Relat__1FCDBCEB");
            });

            modelBuilder.Entity<RelatedPeopleTypes>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Name).HasMaxLength(50);

                entity.Property(e => e.Status).HasColumnName("status");
            });
        }
    }
}
