﻿using System;
using System.Collections.Generic;

namespace PersonInfoAPI.DbModels
{
    public partial class Phones
    {
        public long Id { get; set; }
        public long? TypeId { get; set; }
        public string PhoneNumber { get; set; }
        public long? PersonId { get; set; }
        public bool Status { get; set; }

        public virtual Person Person { get; set; }
        public virtual PhoneTypes Type { get; set; }
    }
}
