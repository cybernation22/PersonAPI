﻿using System;
using System.Collections.Generic;

namespace PersonInfoAPI.DbModels
{
    public partial class PersonImages
    {
        public PersonImages()
        {
            Person = new HashSet<Person>();
        }

        public long Id { get; set; }
        public string Image { get; set; }
        public bool Status { get; set; }

        public virtual ICollection<Person> Person { get; set; }
    }
}
