﻿using Microsoft.EntityFrameworkCore.Storage;
using PersonInfoAPI.DbModels;

namespace PersonInfoAPI.RepoSitory
{
    public class UnitOfWork
    {
        public TBCContext _entities;

        private GenericRepository _genericRepo;

        public UnitOfWork(TBCContext entities)
        {
            _entities = entities;
        }

        public IDbContextTransaction BeginTransaction()
        {
            return _entities.Database.BeginTransaction();
        }

        public void Save()
        {
            _entities.SaveChanges();
        }

    
        public GenericRepository GenericRepo
        {
            get
            {
                if (_genericRepo == null)
                {
                    _genericRepo = new GenericRepository(_entities);
                }
                return _genericRepo;
            }
        }




   
    }
}




