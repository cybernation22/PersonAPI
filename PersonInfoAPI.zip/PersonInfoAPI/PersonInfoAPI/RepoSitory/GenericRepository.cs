﻿using Microsoft.EntityFrameworkCore;
using PersonInfoAPI.CustomModels;
using PersonInfoAPI.DbModels;
using PersonInfoAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PersonInfoAPI.RepoSitory
{
    public class GenericRepository
    {
        private TBCContext _entities;

        public GenericRepository(TBCContext entities)
        {
            _entities = entities;
        }

        public IQueryable<T> GetAll<T>() where T : class
        {
            return _entities.Set<T>();
        }

        public T GetByID<T>(long id) where T : class
        {
            return _entities.Set<T>().Find(id);
        }

        public T Add<T>(T entity) where T : class
        {
            _entities.Set<T>().Add(entity);

            return entity;
        }
        public virtual void AddRange<T>(List<T> entity) where T : class
        {
            _entities.Set<T>().AddRange(entity);
        }

        public void Update<T>(T entity) where T : class
        {
            _entities.Set<T>().Attach(entity);
            _entities.Entry(entity).State = EntityState.Modified;
        }

        public void Delete<T>(T entity) where T : class
        {
            _entities.Set<T>().Remove(entity);
            _entities.Entry(entity).State = EntityState.Deleted;
        }

        public void DeleteRange<T>(List<T> entity) where T : class
        {
            _entities.Set<T>().RemoveRange(entity);
            _entities.Entry(entity).State = EntityState.Deleted;
        }

     
    }
}