﻿using PersonInfoAPI.DbModels;
using System;
using System.Text;

namespace PersonInfoAPI.CustomModels
{
    public class PhoneModel : Phones
    {
        public Enumerators.PhoneTypes phoneTypesEnum
        {
            get
            {
                return (Enumerators.PhoneTypes)TypeId;
            }
        }


        public string GetPhoneTypeEnums { get
            {
                var types = new StringBuilder();
              
                types.Append("Phone Types should be: " + string.Join(", ", Enum.GetNames(typeof(Enumerators.PhoneTypes))));

                return types.ToString();
            }
        }
    }
}
