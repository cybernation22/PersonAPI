﻿using PersonInfoAPI.DbModels;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace PersonInfoAPI.CustomModels
{

    public class PersonModel : Person
    {

        public Enumerators.Sex SexEnum
        {
            get
            {
                return (Enumerators.Sex)Sex;
            }
        }


        public bool IsCorrectFirstName
        { get
            {
                var res =  Regex.IsMatch(Fname, "^[a-zA-Z]*$")
                    || Regex.IsMatch(Fname, "^[ა-ჰ]*$")
                    ;
                return res;

            }
        }


        public bool IsCorrectLastName
        {
            get
            {
                var res = Regex.IsMatch(Lname, "^[a-zA-Z]*$")
                    || Regex.IsMatch(Lname, "^[ა-ჰ]*$")
                    ;
                return res;
            }
        }



        public virtual ICollection<PhoneModel> PhoneModel { get; set; }
        public virtual ICollection<RelatedPeopleModel> RelatedPeopleModel { get; set; }



        public int Age
        {
            get
            {
                return GetAge();
            }
        }

        public int GetAge()
        {
            DateTime now = DateTime.Today;
            int age = now.Year - BirthDate.Year;
            if (now < BirthDate.AddYears(age)) age--;

            return age;
        }
    }
}
