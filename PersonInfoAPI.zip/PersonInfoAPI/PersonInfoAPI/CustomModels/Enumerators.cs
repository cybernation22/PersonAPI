﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PersonInfoAPI.CustomModels
{
    public  static class Enumerators
    {
       public enum Sex { Male=1, Female };
        public enum RelatedPeopleTypes { Colleague = 1, Familiar=2, Relative=3, Other=4 };
        public enum PhoneTypes { Mobile = 1, Office = 2, Other = 3};

    }
}
