﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PersonInfoAPI.CustomModels
{
    public class PersonImageP
    {
        public long PersonID { get; set; }
        public string ImageLoc { get; set; }
    }
}
