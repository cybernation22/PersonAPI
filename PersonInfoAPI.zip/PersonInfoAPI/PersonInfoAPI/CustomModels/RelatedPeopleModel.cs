﻿using PersonInfoAPI.DbModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonInfoAPI.CustomModels
{
    public class RelatedPeopleModel : RelatedPeople
    {


        public long Personid { get; set; }

        public Enumerators.RelatedPeopleTypes RelatedPeopleTypesEnum
        {
            get
            {
                return (Enumerators.RelatedPeopleTypes)RelationTypeId;
            }
        }

       


        public string GetRelatedPeopleTypesEnums
        {
            get
            {
                var types = new StringBuilder();

                types.Append("Related people types  should be: " + string.Join(", ", Enum.GetNames(typeof(Enumerators.RelatedPeopleTypes))));

                return types.ToString();
            }
        }
    }
}
